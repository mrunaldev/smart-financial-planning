# Tax Data Structure and Save Flow

## ⚠️ **CRITICAL FIX - v2.3.21**

The tax data persistence issue has been fixed. The data was being saved to Firestore correctly, but when loading it back, the code was not including `taxData` in the appData object. This has been fixed by adding `taxData: d.taxData || {}` to the Firestore data loading in `startListening()`.

See the "Firestore Save/Load Flow" section below for details.

---

## Complete Data Structure

```javascript
appData = {
    // Root level fields
    tabData: {
        inflow: [],        // Investment entries
        outflow: [],       // Expense entries
        taxPlan: [],       // Manual tax saving items (PPF, ELSS, etc.)
        cards: [],         // Bank accounts
        netWorth: [],      // Assets/Liabilities
        gifts: []          // Gifts
    },
    customTabs: [],
    userName: "",
    monthlyBudgetData: {},
    fixedMonthlyIncome: 0,
    dateOfBirth: "",
    currentAge: 0,
    onboardingComplete: false,
    onboardingDate: "",
    dataMigrated: false,
    
    // Tax planning data (SEPARATE from tabData)
    taxData: {
        salary: {              // Salary details for HRA calculation
            basicSalary: 0,
            hraReceived: 0,
            rentPaid: 0,
            isMetroCity: 'yes'
        },
        houseProperty: {       // House property for Section 24(b)
            rentalIncome: 0,
            municipalTaxes: 0,
            homeLoanInterest: 0,
            isSelfOccupied: 'yes'
        }
    }
}
```

## Why Two Separate Structures?

### `appData.tabData.taxPlan` (Array)
- **Purpose**: Manual tax-saving items entered by user
- **Type**: Array of objects
- **Examples**: PPF, ELSS, LIC, NSC, etc.
- **Saved via**: `setSectionEntries("taxPlan", entries)` → `scheduleSave()`
- **Structure**:
```javascript
[
    { id: "abc123", name: "PPF", section: "80C", amount: 150000, details: "..." },
    { id: "def456", name: "ELSS", section: "80C", amount: 50000, details: "..." }
]
```

### `appData.taxData` (Object)
- **Purpose**: Salary and house property details for calculations
- **Type**: Object with nested objects
- **Examples**: Basic salary, HRA, rent paid, home loan interest
- **Saved via**: `saveSalaryDetailsAuto()` → `scheduleSave()`
- **Structure**:
```javascript
{
    salary: { basicSalary, hraReceived, rentPaid, isMetroCity },
    houseProperty: { rentalIncome, municipalTaxes, homeLoanInterest, isSelfOccupied }
}
```

## Save Flow

### 1. Manual Tax Items (PPF, ELSS, etc.)
```
User fills form → Click "Add" → addTaxPlanEntry()
    ↓
readSectionFormEntry("taxPlan")
    ↓
upsertSectionEntry("taxPlan", entry)
    ↓
setSectionEntries("taxPlan", entries)
    ↓
appData.tabData.taxPlan = entries
    ↓
scheduleSave()
    ↓
doSave()
    ↓
db.collection("users").doc(uid).set(appData, { merge: true })
    ↓
Firestore saves entire appData (including taxData)
```

### 2. Salary Details
```
User fills form → Click "✓ Done" → saveSalaryDetailsAuto()
    ↓
appData.taxData.salary = { basicSalary, hraReceived, ... }
    ↓
scheduleSave()
    ↓
doSave()
    ↓
db.collection("users").doc(uid).set(appData, { merge: true })
    ↓
Firestore saves entire appData (including taxData)
```

### 3. House Property Details
```
User fills form → Click "✓ Done" → saveHousePropertyDetailsAuto()
    ↓
appData.taxData.houseProperty = { rentalIncome, municipalTaxes, ... }
    ↓
scheduleSave()
    ↓
doSave()
    ↓
db.collection("users").doc(uid).set(appData, { merge: true })
    ↓
Firestore saves entire appData (including taxData)
```

## Import/Export

### Export
```javascript
exportDataBtn.addEventListener("click", () => {
    const payload = JSON.stringify({ 
        exportDate: new Date().toISOString(), 
        version: getAppVersion(), 
        data: appData  // ← Entire appData (includes taxData)
    }, null, 2);
    // Download as JSON file
});
```

### Import
```javascript
importFileInput.addEventListener("change", async (e) => {
    const parsed = JSON.parse(file);
    const imported = parsed.data || parsed;
    
    const safeImport = {
        tabData: imported.tabData || {},
        customTabs: imported.customTabs || [],
        userName: imported.userName || "",
        monthlyBudgetData: imported.monthlyBudgetData || {},
        // ... other fields
        taxData: imported.taxData || {}  // ← Restored from backup
    };
    
    db.collection("users").doc(uid).set(safeImport);
});
```

## Data Persistence

### On Page Load
```javascript
auth.onAuthStateChanged(user => {
    if (user) {
        db.collection("users").doc(user.uid).onSnapshot(snapshot => {
            if (snapshot.exists) {
                appData = snapshot.data();  // ← Loads entire appData
                
                // Ensure taxData exists (backward compatibility)
                if (!appData.taxData) appData.taxData = {};
                
                render();
            }
        });
    }
});
```

### normalizeAppDataModel
```javascript
function normalizeAppDataModel() {
    if (!appData.tabData) appData.tabData = {};
    if (!appData.taxData) appData.taxData = {};  // ← Ensures taxData exists
    // ... other normalizations
}
```

## Verification Checklist

✅ **Data Structure**
- `appData.taxData` exists at root level
- `appData.tabData.taxPlan` exists for manual items

✅ **Save Functions**
- `saveSalaryDetailsAuto()` uses `scheduleSave()` (not `saveData()`)
- `saveHousePropertyDetailsAuto()` uses `scheduleSave()` (not `saveData()`)
- `setSectionEntries()` uses `scheduleSave()` for tax plan items

✅ **Firestore Save**
- `doSave()` saves entire `appData` with `{ merge: true }`
- All fields (tabData, taxData, etc.) saved together

✅ **Import/Export**
- Export includes entire `appData` (with taxData)
- Import restores `taxData` from backup

✅ **Data Loading**
- Firestore snapshot loads entire `appData`
- `normalizeAppDataModel()` ensures taxData exists
- Backward compatibility with old data

## Common Issues

### Issue: "saveData is not defined"
**Cause**: Old cached version (before v2.3.12)
**Fix**: Hard refresh browser (Ctrl+Shift+R)

### Issue: "Cannot read properties of undefined (reading 'salary')"
**Cause**: Old cached version (before v2.3.9)
**Fix**: Hard refresh browser (Ctrl+Shift+R)

### Issue: Data not persisting after refresh
**Cause**: taxData not initialized in default appData (before v2.3.15)
**Fix**: Hard refresh browser (Ctrl+Shift+R)

## Current Version: v2.3.15

All issues fixed. Please hard refresh your browser to load the latest version.
